BPM Calendaring
===============

The notion of flagging users as being available for work vs not available for work is discussed in the associated PDF
and Toolkit. The toolkit can be added to a BPM 8.5.0.1 environment. 

* [PDF documentation](docs/BPM Calendaring.pdf)
* [Calendar.TWX toolkit](Calendar.tw)


This repository was created by Neil Kolban for the community while an IBM Employee. This repository was copied over from hub.jazz.net where it was previously hosted.

Examples and libraries provided under the [License](License.txt).  Samples are provided as-is with no warranty or support.